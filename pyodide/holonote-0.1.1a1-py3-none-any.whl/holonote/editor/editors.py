# Move https://github.com/holoviz/holoviews/blob/main/holoviews/annotators.py here
from __future__ import annotations


class PathEditor:
    pass
